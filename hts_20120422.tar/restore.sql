create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.quote_requests DROP CONSTRAINT quote_requests_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.news_items DROP CONSTRAINT news_items_pkey;
ALTER TABLE ONLY public.categories DROP CONSTRAINT categories_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.quote_requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.products ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.news_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.categories ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.schema_migrations;
DROP SEQUENCE public.quote_requests_id_seq;
DROP TABLE public.quote_requests;
DROP SEQUENCE public.products_id_seq;
DROP TABLE public.products;
DROP SEQUENCE public.news_items_id_seq;
DROP TABLE public.news_items;
DROP SEQUENCE public.categories_id_seq;
DROP TABLE public.categories;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE categories (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "position" integer
);


ALTER TABLE public.categories OWNER TO hts;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: hts
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO hts;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hts
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hts
--

SELECT pg_catalog.setval('categories_id_seq', 12, true);


--
-- Name: news_items; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE news_items (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    description character varying(255) NOT NULL
);


ALTER TABLE public.news_items OWNER TO hts;

--
-- Name: news_items_id_seq; Type: SEQUENCE; Schema: public; Owner: hts
--

CREATE SEQUENCE news_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_items_id_seq OWNER TO hts;

--
-- Name: news_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hts
--

ALTER SEQUENCE news_items_id_seq OWNED BY news_items.id;


--
-- Name: news_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hts
--

SELECT pg_catalog.setval('news_items_id_seq', 11, true);


--
-- Name: products; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE products (
    id integer NOT NULL,
    category_id integer NOT NULL,
    company character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    premier boolean NOT NULL,
    "position" integer
);


ALTER TABLE public.products OWNER TO hts;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: hts
--

CREATE SEQUENCE products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_id_seq OWNER TO hts;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hts
--

ALTER SEQUENCE products_id_seq OWNED BY products.id;


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hts
--

SELECT pg_catalog.setval('products_id_seq', 83, true);


--
-- Name: quote_requests; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE quote_requests (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    company character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    fax character varying(255),
    email character varying(255),
    street character varying(255),
    city character varying(255),
    state character varying(255),
    zip character varying(255),
    additional character varying(255),
    date timestamp without time zone NOT NULL
);


ALTER TABLE public.quote_requests OWNER TO hts;

--
-- Name: quote_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: hts
--

CREATE SEQUENCE quote_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quote_requests_id_seq OWNER TO hts;

--
-- Name: quote_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hts
--

ALTER SEQUENCE quote_requests_id_seq OWNED BY quote_requests.id;


--
-- Name: quote_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hts
--

SELECT pg_catalog.setval('quote_requests_id_seq', 1, false);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO hts;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hts; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_digest character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO hts;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: hts
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO hts;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hts
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hts
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hts
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hts
--

ALTER TABLE ONLY news_items ALTER COLUMN id SET DEFAULT nextval('news_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hts
--

ALTER TABLE ONLY products ALTER COLUMN id SET DEFAULT nextval('products_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hts
--

ALTER TABLE ONLY quote_requests ALTER COLUMN id SET DEFAULT nextval('quote_requests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: hts
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY categories (id, name, "position") FROM stdin;
\.
copy categories (id, name, "position")  from '$$PATH$$/2162.dat' ;
--
-- Data for Name: news_items; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY news_items (id, date, description) FROM stdin;
\.
copy news_items (id, date, description)  from '$$PATH$$/2164.dat' ;
--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY products (id, category_id, company, name, premier, "position") FROM stdin;
\.
copy products (id, category_id, company, name, premier, "position")  from '$$PATH$$/2163.dat' ;
--
-- Data for Name: quote_requests; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY quote_requests (id, name, company, phone, fax, email, street, city, state, zip, additional, date) FROM stdin;
\.
copy quote_requests (id, name, company, phone, fax, email, street, city, state, zip, additional, date)  from '$$PATH$$/2166.dat' ;
--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY schema_migrations (version) FROM stdin;
\.
copy schema_migrations (version)  from '$$PATH$$/2161.dat' ;
--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hts
--

COPY users (id, email, password_digest) FROM stdin;
\.
copy users (id, email, password_digest)  from '$$PATH$$/2165.dat' ;
--
-- Name: categories_pkey; Type: CONSTRAINT; Schema: public; Owner: hts; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: news_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hts; Tablespace: 
--

ALTER TABLE ONLY news_items
    ADD CONSTRAINT news_items_pkey PRIMARY KEY (id);


--
-- Name: products_pkey; Type: CONSTRAINT; Schema: public; Owner: hts; Tablespace: 
--

ALTER TABLE ONLY products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quote_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: hts; Tablespace: 
--

ALTER TABLE ONLY quote_requests
    ADD CONSTRAINT quote_requests_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: hts; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: hts; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

